<?php
require_once '../connect.php';
session_start();
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta http-equiv="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Cache-Control" content="no-cache">
<title>Магазин Puzzle</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../style.css" media="screen"/>
<link rel="shortcut icon" href="../images/puzzle.png" type="image/x-icon">


</head>
<body>
<div class="header">
	
	<div class="title">
		<div class="logo">
		<p><img src="../images/puzzle.png" width="100" height="100" ></p>
	</div>


<?php if (isset($_SESSION['logged'])&&$_SESSION['logged']=='true'): ?>
          <a href="../disconnect.php"><img class="user"src="../images/Octicons-sign-out.svg" ></a>
          <p id="login"><?php echo $_SESSION['email'];?></p>
        <?php else: ?>
           <a><img  class="user"src="../images/account%201.svg" id="in"></a>
        <?php endif; ?>

		<div class="name1"><p>Інтернет магазин іграшок</p></div>
		<div class="name2"><p>Puzzle</p></div>

		
	</div>

</div>
<div class="contain"> 
<div class="slider">

    <div class="item">

        <img src="../images/slide1.jpg"id="image_1" alt="Первый слайд">



    </div>

    <div class="item">

        <img src="../images/slide2.jpg" id="image_2" alt="Второй слайд">



    </div>

    <div class="item">

        <img src="../images/slide3.jpg" id="image_3" alt="Третий слайд">



    </div>

      <div class="item">

        <img src="../images/slide4.jpg" id="image_4" alt="Четвёртый слайд">



    </div>



</div>

    <a class="prev" onclick="minusSlide(),scrool=false">&#10094;</a>

    <a class="next" onclick="plusSlide(),scrool=false">&#10095;</a>

<div class="slider-dots">

    <span class="slider-dots_item" onclick="currentSlide(1),scrool=false"></span>

    <span class="slider-dots_item" onclick="currentSlide(2),scrool=false"></span>

    <span class="slider-dots_item" onclick="currentSlide(3),scrool=false"></span>

    <span class="slider-dots_item" onclick="currentSlide(4),scrool=false"></span>

</div>

</div>

<ul id="navbar">
      <li><a href="../index.php">Головна</a></li>
      <li><a href="#">Каталог</a></li>
      <li><a href="#bottom">Контакти</a></li>
      <form action="finder.php" method="post">

  <input type="text" name='name' placeholder="Пошук товару...">
  <button type="submit"></button>

</form>
    </ul>


<form action="filter.php" method="post">
  
<div class="block2" id="filter" hidden="true">
 <p>Фільтри</p>
<span class="custom-dropdown ">  
  <span class="choose">Країна</span>
 <select name="country">  
  <option value="0">Будь-який</option>
<?php 
        $r = mysqli_query($con, "SELECT * FROM countries;");
            $mas = mysqli_fetch_all($r,MYSQLI_ASSOC);
          for ($i = 0 ;$mas[$i]['country_id']!=''; $i++) 
          {
                  echo '<option value="',$mas[$i]['country_id'],'">',$mas[$i]['country_name'],'</option>';
          }
          ?>
 </select> 
</span> 
<span class="custom-dropdown ">  
  <span class="choose">Матеріал</span>
 <select name="material">   
 <option value="0">Будь-який</option>
 <?php 
        $r = mysqli_query($con, "SELECT * FROM materials;");
            $mas = mysqli_fetch_all($r,MYSQLI_ASSOC);
          for ($i = 0 ;$mas[$i]['material_id']!=''; $i++) 
          {
                  echo '<option value="',$mas[$i]['material_id'],'">',$mas[$i]['material_name'],'</option>';
          }
          ?> </select> 
</span> 
<span class="custom-dropdown ">  
  <span class="choose">Категорія</span>
   <select name="category"> 
      <option value="0">Будь-який</option>
<?php 
        $r = mysqli_query($con, "SELECT * FROM categories;");
            $mas = mysqli_fetch_all($r,MYSQLI_ASSOC);
          for ($i = 0 ;$mas[$i]['category_id']!=''; $i++) 
          {
                  echo '<option value="',$mas[$i]['category_id'],'">',$mas[$i]['category_name'],'</option>';
          }
          ?>
 </select> 
</span> 
<button type="submit" class="find_clk">Пошук</button>
</div>
</form>

<div class="buttonHolder">
  <button id="button_find"> </button>
</div>

<div class="content">

  <?php
      if(!isset($_SESSION['query_text'])) $_SESSION['query_text'] = "SELECT * FROM `goods` JOIN `categories` ON `goods`.`category_id`=`categories`.`category_id`;";
      $_SESSION['query'] = mysqli_query($con, $_SESSION['query_text']);
      

      $mas = mysqli_fetch_all($_SESSION['query'],MYSQLI_ASSOC);

          for ($i = 0 ;$mas[$i]['good_id']!=''; $i++) 
          {
            echo '<div class="photo"> 
            <img src="',$mas[$i]['good_image'],'" width="300" height="320" >
            <p class="titl">',$mas[$i]['good_name'],'</p>
            <p class="description">',$mas[$i]['category_name'],'</p>
            <p class="price_text">Ціна: </p>
            <p class="price">',$mas[$i]['good_price'],'</p>
            <p class="price_text">грн</p>
            </div>';
          }
          $_SESSION['query_text'] = "SELECT * FROM `goods` JOIN `categories` ON `goods`.`category_id`=`categories`.`category_id`;";
  ?>

</div>


<div class="footer">
  <a name="bottom"></a>
	<p class="contacts_h">Контакти:</p>
	<p class="contact">+380665794628</p>
	<p class="contact">+380955730626</p>
	<p class="contact">Адреса: Суми, вул. Іллінська, буд.17, 2 поверх</p>

</div>
<script type="text/javascript" src="../scripts/script.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
</body>
</html>