<?php
	require_once '../connect.php';
	session_start();

		$_SESSION['country'] = $_POST["country"];
		$_SESSION['material'] = $_POST["material"];
		$_SESSION['category'] = $_POST["category"];
		
		$_SESSION['query_text'] = "SELECT * FROM `goods` JOIN `categories` ON `goods`.`category_id`=`categories`.`category_id`";

if($_SESSION['country']!='0' || $_SESSION['material']!='0' || $_SESSION['category']!='0')
{
			$added=false;
			if($_SESSION['country']!='0')
			{

				$_SESSION['query_text'].= " WHERE `goods`.`country_id` = " . $_SESSION['country'];
				$added=true;

			}
			if($_SESSION['material']!='0')
			{
				if($added!=true)
				{
				$_SESSION['query_text'].= " WHERE `goods`.`material_id` = " . $_SESSION['material'];
				$added=true;
				}
				else
				$_SESSION['query_text'].= " AND `goods`.`material_id` = " . $_SESSION['material'];
			}
			if($_SESSION['category']!='0')
			{
				if($added!=true)
				{
				$_SESSION['query_text'].= " WHERE `goods`.`category_id` = " . $_SESSION['category'];
				$added=true;
				}
				else
				$_SESSION['query_text'].= " AND `goods`.`category_id` = " . $_SESSION['category'];	 
			}
}

	$_SESSION['query_text'].=" ORDER BY `good_price` ASC;";

if(isset($_SESSION['admin']))
	{
	header('Location: ../admin/index.php');
	}
	else
	{
	header('Location: index.php');
	}
?>