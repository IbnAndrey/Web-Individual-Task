<?php

	require_once '../connect.php';
	session_start();
	$_SESSION['name'] = $_POST["name"];

	
	if($_SESSION['name']!='')
	{
	$_SESSION['query_text'] = "SELECT * FROM `goods` JOIN `categories` ON `goods`.`category_id`=`categories`.`category_id` WHERE `good_name`LIKE '%".$_SESSION['name']."%';";
	}
	if(isset($_SESSION['admin']))
	{
	header('Location: ../admin/index.php');
	}
	else
	{
	header('Location: index.php');
	}
?>