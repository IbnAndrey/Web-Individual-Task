var flag = false;

    document.getElementById('button_find').onclick = function() {
      document.getElementById('filter').hidden = flag;
      flag = !flag;
    }
        var flag1 = false;
    var elem=document.getElementById('edit');
    document.getElementById('open_editgood').onclick = function() {
      elem.hidden = flag1;

      flag1 = !flag1;
    }

            var flag2 = false;
    var elem1=document.getElementById('edit_cat');
    document.getElementById('open_editcategory').onclick = function() {
      elem1.hidden = flag2;

      flag2 = !flag2;
    }
