var slideIndex = 1;
  var interval = 5000;    // задержка между изображениями
  var f = 0;
  var scrool=true;

  setInterval (
    function() {
    if(scrool==true)
      {
        plusSlide();
      }
    }, interval
  );

showSlides(slideIndex);

/* Функуція збільшує індекс на 1, відображає наступний слайд */

function plusSlide() {

    showSlides(slideIndex += 1);

}

/* Функція зменшує індекс на 1, відображає попередній слайд*/

function minusSlide() {

    showSlides(slideIndex -= 1); 

}

/* Функція встановлює поточний  слайд */

function currentSlide(n) {

    showSlides(slideIndex = n);

}

/* Основна функція слайдера */

function showSlides(n) {

    var i;

    var slides = document.getElementsByClassName("item");

    var dots = document.getElementsByClassName("slider-dots_item");

    if (n > slides.length) {

      slideIndex = 1

    }

    if (n < 1) {

        slideIndex = slides.length

    }

    for (i = 0; i < slides.length; i++) {

        slides[i].style.display = "none";

    }

    for (i = 0; i < dots.length; i++) {

        dots[i].className = dots[i].className.replace(" active", "");

    }

    slides[slideIndex - 1].style.display = "block";

    dots[slideIndex - 1].className += " active";

}

/*$('.dropdown').click(function () {
        $(this).attr('tabindex', 1).focus();
        $(this).toggleClass('active');
        $(this).find('.dropdown-menu').slideToggle(300);
    });
    $('.dropdown').focusout(function () {
        $(this).removeClass('active');
        $(this).find('.dropdown-menu').slideUp(300);
    });
    $('.dropdown .dropdown-menu li').click(function () {
        $(this).parents('.dropdown').find('span').text($(this).text());
        $(this).parents('.dropdown').find('input').attr('value', $(this).attr('id'));
    });



$('.dropdown-menu li').click(function () {
  var input = '<strong>' + $(this).parents('.dropdown').find('input').val() + '</strong>',
      msg = '<span class="msg">Hidden input value: ';
  $('.msg').html(msg + input + '</span>');
}); 
*/

$("#user").click(function () {
$("#auth").toggleClass("shadow");
})


var flag = false;

    document.getElementById('button_find').onclick = function() {
      document.getElementById('filter').hidden = flag;
      flag = !flag;
    }

    var flag1 = false;
    var elem=document.getElementById('auth');
    document.getElementById('user').onclick = function() {
      elem.hidden = flag1;

      flag1 = !flag1;
    }
    
document.getElementById('close').onclick = function() {
      elem.hidden = flag1;

      flag1 = !flag1;
    }



