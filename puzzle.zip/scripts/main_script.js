var slideIndex = 1;
  var interval = 5000;    // задержка между изображениями
  var f = 0;
  var scrool=true;
var reg = false;

  setInterval (
    function() {
    if(scrool==true)
      {
        plusSlide();
      }
    }, interval
  );

showSlides(slideIndex);

/* Функуція збільшує індекс на 1, відображає наступний слайд */

function plusSlide() {

    showSlides(slideIndex += 1);

}

/* Функція зменшує індекс на 1, відображає попередній слайд*/

function minusSlide() {

    showSlides(slideIndex -= 1); 

}

/* Функція встановлює поточний  слайд */

function currentSlide(n) {

    showSlides(slideIndex = n);

}

/* Основна функція слайдера */

function showSlides(n) {

    var i;

    var slides = document.getElementsByClassName("item");

    var dots = document.getElementsByClassName("slider-dots_item");

    if (n > slides.length) {

      slideIndex = 1

    }

    if (n < 1) {

        slideIndex = slides.length

    }

    for (i = 0; i < slides.length; i++) {

        slides[i].style.display = "none";

    }

    for (i = 0; i < dots.length; i++) {

        dots[i].className = dots[i].className.replace(" active", "");

    }

    slides[slideIndex - 1].style.display = "block";

    dots[slideIndex - 1].className += " active";

}

$("#in").click(function () {
$("#auth").toggleClass("shadow");
})



 var flag1 = false;
    var elem=document.getElementById('auth');
    
    document.getElementById('in').onclick = function() {
      elem.hidden = flag1;

      flag1 = !flag1;
    }
    
