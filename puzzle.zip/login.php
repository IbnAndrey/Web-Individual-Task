<?php

	require_once 'connect.php';
	session_start();
	if ($_POST["email"]== 'admin@gmail.com' and $_POST["password"]== 'admin')	{
		$_SESSION['logged'] = true;
		$_SESSION['admin'] = true;
		header('Location: admin/index.php');
	}
	else 
	{
	
			$_SESSION['email'] = $_POST["email"];
			$pass = $_POST["password"];
			$res = mysqli_query($con, "SELECT * FROM `users` WHERE `email` = '" . $_SESSION['email'] . "';");
       		 $users = mysqli_fetch_array($res,MYSQLI_ASSOC);
			if ($pass != $users['password'] && isset( $_POST['reg'])) {

			
			$r = mysqli_query($con, "SELECT * FROM `users`");
    		$id = mysqli_num_rows($r)+1;
			$sql="INSERT INTO `users`(`user_id`, `email`, `password`) VALUES ('{$id}', '{$_SESSION['email']}', '{$pass}')";
			mysqli_query($con, $sql);
			$_SESSION['logged'] = true;
			header('Location: catalog/index.php');
			}
			else {
				 $_SESSION['logged'] = true;
				 
			}
				header('Location: index.php');

	}
?>