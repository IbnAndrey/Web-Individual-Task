<?php


	define("DB_SERVER", "localhost");
	define("DB_USER", "ibnandrey");
	define("DB_PASS", "Kentavr19");
	define("DB_NAME", "ibnandrey");
	$con = mysqli_connect(DB_SERVER,DB_USER, DB_PASS, DB_NAME) or die(mysqli_error());


    ?>