<?php
require_once 'connect.php';
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta http-equiv="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Cache-Control" content="no-cache">
<title>Магазин Puzzle</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css" media="screen"/>
<link rel="shortcut icon" href="images/puzzle.png" type="image/x-icon">
</head>
<body>
<div class="header">
	
	<div class="title">
		<div class="logo">
		<p><img src="images/puzzle.png" width="100" height="100" ></p>
	</div>
	
  

<?php if (isset($_SESSION['logged'])&&$_SESSION['logged']=='true'): ?>
          
          <a href="disconnect.php"><img class="user"src="images/Octicons-sign-out.svg" ></a>
          <p id="login"><?php echo $_SESSION['email'];?></p>
        <?php else: ?>
           <a><img  class="user"src="images/account%201.svg" id="in"></a>
        <?php endif; ?>


		<div class="name1"><p>Інтернет магазин іграшок</p></div>
		<div class="name2"><p>Puzzle</p></div>

		
	</div>
</div>
<div id="auth" hidden="true">
<form id ="auth" name='form' action="login.php" method="post">	
<p class="auth_head">Авторизація</p>
<p class="auth_title">Email: <input type='email' name='email' required> </p>
<p class="auth_title">Пароль: <input type='password' name='password' required></p>
<p id="error"> </p>
<button type="submit" class="auth_clk">Вхід</button>
<button type="submit" class="auth_clk" name="reg">Реєстрація</button>
<span id='log'></span><br/>


</form>
</div>
<div class="contain"> 
<div class="slider">

    <div class="item">

        <img src="images/slide1.jpg"id="image_1" alt="Первый слайд">



    </div>

    <div class="item">

        <img src="images/slide2.jpg" id="image_2" alt="Второй слайд">



    </div>

    <div class="item">

        <img src="images/slide3.jpg" id="image_3" alt="Третий слайд">



    </div>

      <div class="item">

        <img src="images/slide4.jpg" id="image_4" alt="Четвёртый слайд">



    </div>



</div>

    <a class="prev" onclick="minusSlide(),scrool=false">&#10094;</a>

    <a class="next" onclick="plusSlide(),scrool=false">&#10095;</a>

<div class="slider-dots">

    <span class="slider-dots_item" onclick="currentSlide(1),scrool=false"></span>

    <span class="slider-dots_item" onclick="currentSlide(2),scrool=false"></span>

    <span class="slider-dots_item" onclick="currentSlide(3),scrool=false"></span>

    <span class="slider-dots_item" onclick="currentSlide(4),scrool=false"></span>

</div>

</div>

<ul id="navbar">
      <li><a href="">Головна</a></li>
            <?php if (isset($_SESSION['logged'])&&$_SESSION['logged']=='true'): ?>
           <li><a href="./catalog/">Каталог</a></li>
        <?php else: ?>
           <li><a href="">Каталог</a></li>
        <?php endif; ?>
      <li><a href="#bottom">Контакти</a></li>

      <form>


</form>
    </ul>




</div>



<div class="main_content">
    <h1>Доброго дня!</h1>

    <div class="welcome_text"> 
       <p>Вас вітає інтернет-магазин іграшок Puzzle</p>
       <p>На нашому сайті ви зможете підібрати для своєї дитини іграшку на будь-який смак. В товарному асортименті наявні іграшки для
       всіх вікових груп. Щоб переглянути товари, які ми можемо вам запропонувати, треба авторизуватися на сайті або, якщо ви
       ще не маєте облікового запису - спочатку пройдіть реєстрацію. Зробити це можна натиснувши на кнопку в правому верхньому кутку сторінки сайту.</p>
        <h3>Бажаємо, щоб наші товари стали улюбеними іграшками для вашої дитини ;)</h3>

    </div>
</div>


<div class="footer">
  <a name="bottom"></a>
	<p class="contacts_h">Контакти:</p>
	<p class="contact">+380665794628</p>
	<p class="contact">+380955730626</p>
	<p class="contact">Адреса: Суми, вул. Іллінська, буд.17, 2 поверх</p>

</div>
<script type="text/javascript" src="scripts/main_script.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
</body>
</html>