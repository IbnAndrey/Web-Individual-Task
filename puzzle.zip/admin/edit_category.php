<?php
	require_once '../connect.php';
	session_start();


		if(isset($_POST["delete"])&&$_POST["category"]!='0')
			{
				mysqli_query($con, "DELETE FROM `categories` WHERE `categories`.`category_id` = '".$_POST["category"]."';");
			}
			else if (isset($_POST["edit"])&&$_POST["edit_id"]!=''&&$_POST["edit_name"]!='') 
				{
					mysqli_query($con,"UPDATE `categories` SET `category_name` = '".$_POST["edit_name"]."' WHERE `categories`.`category_id` = '".$_POST["edit_id"]."';");
				}
				else if(isset($_POST["add"])&&$_POST["edit_id"]!=''&&$_POST["edit_name"]!='')
					{
						mysqli_query($con,"INSERT INTO `categories`(`category_id`, `category_name`) VALUES ('{$_POST["edit_id"]}', '{$_POST["edit_name"]}');");
					}

header('Location: index.php');
?>