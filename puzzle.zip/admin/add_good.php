<?php
require_once '../connect.php';
session_start();
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta http-equiv="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Cache-Control" content="no-cache">
<title>Магазин Puzzle</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../style.css" media="screen"/>
<link rel="shortcut icon" href="../images/puzzle.png" type="image/x-icon">


</head>
<body>
<div class="header">
	
	<div class="title">
		<div class="logo">
		<p><img src="../images/puzzle.png" width="100" height="100" ></p>
	</div>


<?php if (isset($_SESSION['logged'])&&$_SESSION['logged']=='true'): ?>
          <a href="../disconnect.php"><img class="user"src="../images/Octicons-sign-out.svg" ></a>
          <p id="login"><?php echo $_SESSION['email'];?></p>
        <?php else: ?>
           <a><img  class="user"src="../images/account%201.svg" id="in"></a>
        <?php endif; ?>

		<div class="name1"><p>Інтернет магазин іграшок</p></div>
		<div class="name2"><p>Puzzle</p></div>

		
	</div>

</div>


<ul id="navbar">
      <li><a href="index.php">Головна(адмін)</a></li>
      <li><a href="add_good.php">Додати товар</a></li>
      <li><a href="add_category.php">Додати категорію</a></li>
</ul>






<div class="content">

  

</div>


<div class="footer">
  <a name="bottom"></a>
	<p class="contacts_h">Контакти:</p>
	<p class="contact">+380665794628</p>
	<p class="contact">+380955730626</p>
	<p class="contact">Адреса: Суми, вул. Іллінська, буд.17, 2 поверх</p>

</div>
<script type="text/javascript" src="../scripts/script.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
</body>
</html>