<?php
	require_once '../connect.php';
	session_start();

	$edit_query="UPDATE `goods` ";
	
	if(isset($_POST["delete"])&&$_POST["delete_id"]!='')
	{
		mysqli_query($con, "DELETE FROM `goods` WHERE `goods`.`good_id` = ".$_POST["delete_id"].";");
		header('Location: index.php');
	}
	else if (isset($_POST["edit"])&&$_POST["edit_id"]!='') 
		{
			$added=false;
			if ($_POST["edit_name"]!='') 
			{
				$edit_query.="SET `good_name` = '".$_POST["edit_name"]."'";
				$added=true;
			}
			if ($_POST["edit_price"]!='') 
			{
				if($added!=true)
				{
				$edit_query.="SET `good_price` = '".$_POST["edit_price"]."'";
				$added=true;
				}
				else
				{
					$edit_query.=", `good_price` = '".$_POST["edit_price"]."'";
				}
			}
			if ($_POST["country"]!='0') 
			{
				if($added!=true)
				{
				$edit_query.="SET `goods`.`country_id` = '".$_POST["country"]."'";
				$added=true;
				}
				else
				{
					$edit_query.=", `goods`.`country_id` = '".$_POST["country"]."'";
				}
			}
			if ($_POST["material"]!='0') 
			{
				if($added!=true)
				{
				$edit_query.="SET `goods`.`material_id` = '".$_POST["material"]."'";
				$added=true;
				}
				else
				{
					$edit_query.=", `goods`.`material_id` = '".$_POST["material"]."'";
				}
			}
			if ($_POST["category"]!='0') 
			{
				if($added!=true)
				{
				$edit_query.="SET `goods`.`category_id` = '".$_POST["category"]."'";
				$added=true;
				}
				else
				{
					$edit_query.=", `goods`.`category_id` = '".$_POST["category"]."'";
				}
			}
			$edit_query.= " WHERE `goods`.`good_id` = '".$_POST["edit_id"]."';";
			mysqli_query($con,$edit_query);
			header('Location: index.php');
		}
		else if(isset($_POST["add"]) && $_FILES["userfile"]!="none" && $_POST["edit_id"] && $_POST["edit_name"] && $_POST["edit_price"] && $_POST["country"] && $_POST["material"] && $_POST["category"]) 
			{
			$userfile = $_FILES["userfile"];
	        $userfile_name = $_FILES["userfile"]["name"];
	        $userfile_size = $_FILES["userfile"]["size"];
	        $userfile_type = $_FILES["userfile"]["type"];
	        $target_dir = "../images/";
	        $target_file = $target_dir . basename($userfile_name);
	        if (!in_array($userfile_type, 
    	    array(
            'jpg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
       		 ))) {
            throw new RuntimeException('Invalid file format.');
        		}
        if (!is_uploaded_file($_FILES['userfile']['tmp_name'])) {
            echo "Problem: possible file upload attack"; 
            exit;
        }
        
        if (!move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
            echo "File cannot be moved";
        }
			$add_query= "INSERT INTO `goods`(`good_id`, `good_name`, `good_price`, `country_id`, `material_id`, `category_id`, `good_image`) VALUES ('{$_POST["edit_id"]}', '{$_POST["edit_name"]}', '{$_POST["edit_price"]}','{$_POST["country"]}','{$_POST["material"]}','{$_POST["category"]}', '{$target_file}');";
			mysqli_query($con,$add_query);
			}
			else header('Location: index.php');

