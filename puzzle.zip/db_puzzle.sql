-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 26 2021 г., 11:05
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `db_puzzle`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'Конструктор LEGO'),
(2, 'Розумні іграшки'),
(3, 'Іграшки для малечі'),
(4, 'М\'які іграшки'),
(5, 'Змінено');

-- --------------------------------------------------------

--
-- Структура таблицы `countries`
--

CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `countries`
--

INSERT INTO `countries` (`country_id`, `country_name`) VALUES
(1, 'Україна'),
(2, 'Китай');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `good_id` int(11) NOT NULL,
  `good_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `good_price` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `good_image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`good_id`, `good_name`, `good_price`, `country_id`, `material_id`, `category_id`, `good_image`) VALUES
(1, 'Конструктор LEGO Пожежна Вежа', 125, 2, 1, 1, '../images/lego_fire.jpeg'),
(2, 'Конструктор LEGO Маяк', 110, 2, 1, 1, '../images/lego_prison.jpg'),
(3, 'Конструктор LEGO Гараж', 120, 2, 1, 1, '../images/lego_garage.jpeg'),
(4, 'Кубик Рубіка 4х4', 40, 2, 1, 2, '../images/rubik_4x4.jpg'),
(5, 'Кубик Рубіка 3х3', 30, 2, 1, 2, '../images/rubik_3x3.jpg'),
(6, 'Бізіборд GoodPlay \"Хатка\"', 800, 1, 2, 2, '../images/buzy_cube.jpg'),
(7, 'Дерев\'яний Лабіринт Viga Toys Polar', 549, 1, 1, 3, '../images/labirynth.jpg'),
(8, 'Муз. Інструмент Goki Ксилофон На 12 Нот', 380, 1, 2, 2, '../images/wood_mus.jpg'),
(9, 'Пазл-Вкладиш Tatev Абетка', 280, 1, 2, 3, '../images/alphabet.jpg'),
(10, 'Плюшевый Ведмідь Hermann Teddy Pepper', 325, 2, 3, 4, '../images/bear_brown.jpg'),
(11, 'Плюшевый Ведмідь Панда Karinka', 285, 2, 3, 4, '../images/panda.jpg'),
(12, 'Космонавт Among Us Cиній', 400, 2, 3, 4, '../images/among_us_cyan.JPG'),
(18, 'Тестовий', 2000, 2, 2, 1, '../images/lego_fire.jpeg');

-- --------------------------------------------------------

--
-- Структура таблицы `materials`
--

CREATE TABLE `materials` (
  `material_id` int(11) NOT NULL,
  `material_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `materials`
--

INSERT INTO `materials` (`material_id`, `material_name`) VALUES
(1, 'Пластик'),
(2, 'Дерево'),
(3, 'Плюш'),
(4, 'Метал');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`) VALUES
(1, 'Ibn.Andrey2001@gmail.com', 'vasilisk'),
(2, 'Ibn.Andrey@gmail.com', 'qwerty'),
(3, 'ruslana.livinets@mail.ru', 'qwerty'),
(4, 'Ibn.And@gmail.com', 'qwerty'),
(5, 'Ibn.Andrey2000000001@gmail.com', 'basilik'),
(6, 'Ibn@gmail.com', 'asdfghj');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Индексы таблицы `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`country_id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`good_id`),
  ADD KEY `category_id` (`category_id`) USING BTREE;

--
-- Индексы таблицы `materials`
--
ALTER TABLE `materials`
  ADD PRIMARY KEY (`material_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
